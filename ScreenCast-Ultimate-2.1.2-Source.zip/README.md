# ScreenCast Ultimate 2.1.2

Maintenance update to the 2.0 source archive; Android versionCode 6 / versionName 2.1.2.

Android screen mirroring over the local Wi-Fi network. The existing browser-based playback path is retained: Android MediaProjection -> OpenGL -> H.264 MediaCodec -> fragmented MP4 -> HTTP/MSE in the TV browser. Optional app-audio capture uses AudioPlaybackCapture -> AAC.

## Improvements in this build

- Browser playback now applies read backpressure: it requests the next network chunk only after the current MSE append completes. This prevents an unbounded JavaScript queue from accumulating stale video during slow playback.
- Live-edge recovery is less aggressive: the player only jumps forward when it is more than 1.25 seconds behind, targeting a 300 ms live buffer.
- AAC fragments use the encoder-provided presentation timestamp for each frame instead of accumulating a synthetic timestamp, reducing long-session audio drift.
- Dropped PCM blocks advance the audio input timeline, so a temporarily busy AAC encoder does not make later audio play progressively slower.
- EGL renderer resources are released on the capture thread before the video encoder is torn down.
- Android package version is now 2.0.0 (versionCode 2) and the app is branded ScreenCast Ultimate.

- Select 480p, 720p or 1080p output, 30 or 60 FPS, and 1–15 Mbps video bitrate. Settings are saved and apply to the next session.
- Adaptive bitrate now steps down after client queue congestion and cautiously recovers by 5% every 10 seconds after 20 seconds without a new congestion event; resolution remains fixed for the session.
- Audio capture is optional. Denying/turning off audio does not prevent video casting. Some source apps intentionally disallow playback capture.
- Live diagnostics show measured video FPS, encoded video bitrate, connected browser viewers, and dropped fragments.
- Session access code expanded from 6 to 16 random characters.
- HTTP request read timeout, maximum of 3 simultaneous viewers, queue overflow accounting, and keyframe resynchronization for slow viewers.
- TV browser playback keeps the existing MSE/fMP4 compatibility route and the DLNA discovery/control flow.

## Important compatibility notes

- 60 FPS and 1080p are device/encoder dependent. If a phone cannot sustain the selected profile, choose 480p or 720p at 30 FPS and a lower bitrate.
- AudioPlaybackCapture requires Android 10+ and the user's runtime permission. The source app must permit playback capture; protected or restricted apps may remain silent.
- The TV browser must support Media Source Extensions with H.264 (and AAC when audio is enabled). DLNA renderer support varies by vendor/model.
- The app's HTTP stream is intended for a trusted local Wi-Fi network. The session code is a basic access barrier, not TLS encryption. Do not expose port 8080 to the public internet.

## WebRTC status (2.1.2)

- WebRTC now captures the screen through a custom `VideoCapturer` backed by one `MediaProjection`. The same projection is shared with Android `AudioPlaybackCapture`, avoiding a second projection-consent token (important on Android 14+).
- When audio is enabled and `RECORD_AUDIO` permission is granted, phone playback is captured as 48 kHz stereo PCM and sent over a WebRTC data channel. The TV receiver schedules PCM through the Web Audio API. This is device/app playback capture, not microphone capture; protected apps or apps that disallow capture may remain silent.
- The TV receiver page fills the viewport and displays Connect / Ignore before starting WebRTC signaling. When a DLNA renderer was selected, the app attempts to open the receiver page on that renderer. DLNA support for HTML receiver pages varies by TV, so manual opening of the shown URL may still be required.
- MSE's fragmented-MP4 player and MSE audio pipeline were not changed by the WebRTC audio implementation.
- WebRTC audio timing and compatibility still require runtime testing on the target phone and VIDAA TV. This source archive has not yet been built or tested on physical hardware; do not treat these changes as verified until the CI APK and device test succeed.

## Build

Open the project in Android Studio with JDK 17 and Android SDK 34 installed, then build the `app` debug variant. The archive does not include the Gradle wrapper, so Android Studio/Gradle must supply the build tooling.


## Version 2.1.2 implementation notes

- The WebRTC signaling server remains on TCP 8081 and the receiver page on TCP 8080. STUN is configured for ICE; this build targets same-LAN use and does not include TURN relay support.
- Raw PCM over the data channel is intentionally used for the first implementation to avoid depending on microphone capture or a custom native WebRTC audio device module. It consumes more LAN bandwidth than Opus.
- Android playback capture is subject to Android's capture policy and the source application's `allowAudioPlaybackCapture` behavior.
