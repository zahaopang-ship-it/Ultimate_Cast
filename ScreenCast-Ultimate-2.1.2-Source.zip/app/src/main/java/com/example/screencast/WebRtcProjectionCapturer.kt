package com.example.screencast

import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.view.Surface
import org.webrtc.CapturerObserver
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoCapturer
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Screen capturer that shares one MediaProjection with AudioPlaybackCapture (Android 14 single-use safe). */
internal class WebRtcProjectionCapturer(
    private val projection: MediaProjection,
    private val onProjectionStopped: () -> Unit
) : VideoCapturer {
    private var helper: SurfaceTextureHelper? = null
    private var observer: CapturerObserver? = null
    private var surface: Surface? = null
    private var display: VirtualDisplay? = null
    private var width = 0
    private var height = 0
    private var densityDpi = 320
    private val stopped = AtomicBoolean(false)
    private val main = Handler(Looper.getMainLooper())
    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            stopCapture()
            onProjectionStopped()
        }
    }

    override fun initialize(surfaceTextureHelper: SurfaceTextureHelper, context: Context, capturerObserver: CapturerObserver) {
        helper = surfaceTextureHelper
        observer = capturerObserver
        densityDpi = context.resources.displayMetrics.densityDpi
    }

    override fun startCapture(width: Int, height: Int, framerate: Int) {
        this.width = width
        this.height = height
        stopped.set(false)
        main.post {
            try {
                projection.registerCallback(projectionCallback, main)
                helper?.setTextureSize(width, height)
                surface = Surface(helper!!.surfaceTexture)
                display = projection.createVirtualDisplay(
                    "ScreenCast-WebRTC", width, height,
                    densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    surface, null, main
                )
                helper!!.startListening { frame -> observer?.onFrameCaptured(frame) }
                observer?.onCapturerStarted(true)
            } catch (t: Throwable) {
                observer?.onCapturerStarted(false)
                onProjectionStopped()
            }
        }
    }

    override fun stopCapture() {
        if (!stopped.compareAndSet(false, true)) return
        val release = {
            runCatching { helper?.stopListening() }
            runCatching { display?.release() }
            display = null
            runCatching { surface?.release() }
            surface = null
            runCatching { projection.unregisterCallback(projectionCallback) }
        }
        if (Looper.myLooper() == Looper.getMainLooper()) release()
        else {
            val latch = CountDownLatch(1)
            main.post { try { release() } finally { latch.countDown() } }
            runCatching { latch.await(700, TimeUnit.MILLISECONDS) }
        }
    }

    override fun changeCaptureFormat(width: Int, height: Int, framerate: Int) {
        if (this.width == width && this.height == height) return
        this.width = width; this.height = height
        main.post {
            runCatching { helper?.setTextureSize(width, height) }
            runCatching { display?.resize(width, height, densityDpi) }
        }
    }

    override fun dispose() { stopCapture(); helper = null; observer = null }
    override fun isScreencast(): Boolean = true
}
