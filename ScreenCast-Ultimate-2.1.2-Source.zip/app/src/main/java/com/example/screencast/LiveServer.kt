package com.example.screencast

import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread

/**
 * Tiny HTTP server:  GET /          -> full-screen player page (MediaSource Extensions, live-edge catch-up)
 *                    GET /live.mp4  -> endless fragmented MP4 (init segment, then frames from a keyframe)
 * Each viewer has its own queue + writer thread, so a slow TV can never stall the encoder.
 */
class LiveServer(private val port: Int, private val token: String, private val requestKeyFrame: () -> Unit, private val onCongestion: () -> Unit = {}) {
    @Volatile var initSegment: ByteArray? = null
    @Volatile var codec: String = "avc1.640028"

    private data class Packet(val ptsUs: Long, val bytes: ByteArray, val key: Boolean, val queuedAtNs: Long = System.nanoTime())
    private class Client(val sock: Socket) {
        // Keep a short reorder window so audio/video callbacks arriving on different
        // codec threads are appended to MSE in presentation-time order.
        val q = LinkedBlockingQueue<Packet>(120)
        @Volatile var needKey = true
    }

    private val clients = CopyOnWriteArrayList<Client>()
    private val dropped = AtomicLong(0)
    val viewerCount: Int get() = clients.size
    val droppedFragments: Long get() = dropped.get()
    private var server: ServerSocket? = null
    @Volatile private var running = false

    fun start() {
        running = true
        thread(name = "live-accept", isDaemon = true) {
            try {
                server = ServerSocket(port)
                while (running) { val s = server!!.accept(); thread(isDaemon = true) { handle(s) } }
            } catch (_: Exception) { }
        }
    }

    private fun handle(s: Socket) {
        var c: Client? = null
        try {
            s.tcpNoDelay = true
            s.soTimeout = 10_000 // never let a half-open HTTP request occupy a worker forever
            val br = s.getInputStream().bufferedReader()
            val path = br.readLine()?.split(" ")?.getOrNull(1) ?: return
            while (br.readLine()?.isNotEmpty() == true) { }
            val out = s.getOutputStream()

            // Secret code check: every request (page AND stream) must carry ?k=<token>.
            val given = Regex("[?&]k=([A-Za-z0-9]+)").find(path)?.groupValues?.get(1)?.uppercase() ?: ""
            if (!MessageDigest.isEqual(given.toByteArray(), token.toByteArray())) {
                Thread.sleep(300) // slows down guessing
                val msg = "Forbidden: wrong or missing code".toByteArray()
                out.write(("HTTP/1.1 403 Forbidden\r\nContent-Type: text/plain\r\nContent-Length: ${msg.size}\r\nConnection: close\r\n\r\n").toByteArray())
                out.write(msg); out.flush()
                return
            }

            if (path.startsWith("/live.mp4")) {
                if (clients.size >= 3) {
                    val msg = "Too many viewers".toByteArray()
                    out.write(("HTTP/1.1 503 Service Unavailable\r\nContent-Length: ${msg.size}\r\nConnection: close\r\n\r\n").toByteArray())
                    out.write(msg); out.flush(); return
                }
                s.soTimeout = 0
                var waited = 0
                while (initSegment == null && waited++ < 50) Thread.sleep(100)
                val init = initSegment ?: return
                out.write(("HTTP/1.1 200 OK\r\nContent-Type: video/mp4\r\nCache-Control: no-cache\r\n" +
                        "Access-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n").toByteArray())
                out.write(init); out.flush()
                c = Client(s).also { clients.add(it) }
                requestKeyFrame()
                while (running) {
                    val first = c.q.poll(2, TimeUnit.SECONDS) ?: continue
                    val batch = ArrayList<Packet>(16)
                    batch.add(first)
                    Thread.sleep(25) // bounded cross-track reorder window
                    c.q.drainTo(batch)
                    batch.sortBy { it.ptsUs }
                    for (packet in batch) { out.write(packet.bytes) }
                    out.flush()
                }
            } else {
                val body = (if (path.startsWith("/webrtc")) webRtcPage(token) else page(codec, token)).toByteArray()
                out.write(("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nCache-Control: no-store\r\nReferrer-Policy: no-referrer\r\n" +
                        "Content-Length: ${body.size}\r\nConnection: close\r\n\r\n").toByteArray())
                out.write(body); out.flush()
            }
        } catch (_: Exception) {
        } finally {
            c?.let { clients.remove(it) }
            runCatching { s.close() }
        }
    }

    /** Called from the encoder callback thread for every encoded frame. */
    fun push(fragment: ByteArray, key: Boolean, ptsUs: Long) {
        for (c in clients) {
            if (c.needKey) { if (!key) continue; c.needKey = false }
            if (!c.q.offer(Packet(ptsUs, fragment, key))) {
                dropped.incrementAndGet(); c.q.clear(); c.needKey = true
                requestKeyFrame(); onCongestion()
            }
        }
    }

    /** Audio uses the same MediaCodec presentation clock as video. */
    fun pushAudio(fragment: ByteArray, ptsUs: Long) {
        for (c in clients) {
            if (c.needKey) continue
            if (!c.q.offer(Packet(ptsUs, fragment, false))) {
                dropped.incrementAndGet(); c.q.clear(); c.needKey = true
                requestKeyFrame(); onCongestion()
            }
        }
    }


    private fun webRtcPage(token: String) = """
<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
:root{color-scheme:dark}*{box-sizing:border-box}
html,body{margin:0;padding:0;width:100%;height:100%;height:100dvh;background:#000;color:#f3f8ff;font-family:system-ui,sans-serif;overflow:hidden}
#v{position:fixed;inset:0;display:block;width:100vw;height:100%;height:100dvh;object-fit:fill;background:#000;border:0}
#status{position:fixed;top:12px;left:12px;z-index:4;padding:8px 12px;border:1px solid #245071;border-radius:12px;background:#071c30dc;font-size:13px}
#consent{position:fixed;inset:0;z-index:5;display:flex;align-items:center;justify-content:center;padding:24px;background:#061426eF}
.panel{width:min(92vw,460px);padding:26px;border:1px solid #245071;border-radius:22px;background:#10243a;text-align:center;box-shadow:0 18px 60px #0009}
h2{margin:0 0 10px;font-size:22px}.desc{color:#c3d5e7;line-height:1.5;margin:0 0 22px}
.actions{display:flex;gap:12px}.actions button{flex:1;border:0;border-radius:13px;padding:14px 10px;font-size:16px;font-weight:700}
#connect{background:#35c9ed;color:#062033}#ignore{background:#293d52;color:#fff}
</style></head><body>
<video id="v" autoplay playsinline></video>
<div id="status">ScreenCast · Waiting for your permission</div>
<div id="consent"><div class="panel">
<h2>ScreenCast connection request</h2>
<p class="desc">A phone on your Wi-Fi network wants to mirror its screen to this TV. Do you want to connect?</p>
<div class="actions"><button id="ignore">Ignore</button><button id="connect">Connect</button></div>
</div></div>
<script>
const video=document.getElementById('v'),status=document.getElementById('status');
const consent=document.getElementById('consent');
let pc=null,ws=null,pending=[],started=false,audioCtx=null,nextAudioTime=0;
function playPcm(data){
 if(!audioCtx||!(data instanceof ArrayBuffer))return;
 const samples=new Int16Array(data),frames=Math.floor(samples.length/2);if(!frames)return;
 const buffer=audioCtx.createBuffer(2,frames,48000),left=buffer.getChannelData(0),right=buffer.getChannelData(1);
 for(let i=0;i<frames;i++){left[i]=samples[i*2]/32768;right[i]=samples[i*2+1]/32768;}
 const src=audioCtx.createBufferSource();src.buffer=buffer;src.connect(audioCtx.destination);
 const now=audioCtx.currentTime;if(nextAudioTime<now+0.025||nextAudioTime>now+0.25)nextAudioTime=now+0.06;
 src.start(nextAudioTime);nextAudioTime+=frames/48000;
}
function connect(){
 if(started)return;started=true;consent.style.display='none';
 status.textContent='Connecting to ScreenCast…';
 pc=new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});
 try{audioCtx=new (window.AudioContext||window.webkitAudioContext)({sampleRate:48000});audioCtx.resume();}catch(e){}
 pc.ondatachannel=e=>{if(e.channel.label==='screencast-audio'){e.channel.binaryType='arraybuffer';e.channel.onmessage=ev=>playPcm(ev.data);}};
 pc.ontrack=e=>{video.srcObject=e.streams[0];video.play().catch(()=>{});status.textContent='Connected · WebRTC';};
 pc.oniceconnectionstatechange=()=>{status.textContent='WebRTC · '+pc.iceConnectionState;};
 pc.onicecandidate=e=>{if(e.candidate&&ws&&ws.readyState===1)ws.send(JSON.stringify({type:'candidate',candidate:e.candidate.candidate,sdpMid:e.candidate.sdpMid,sdpMLineIndex:e.candidate.sdpMLineIndex}));};
 ws=new WebSocket('ws://'+location.hostname+':8081/?k=$token');
 ws.onmessage=async e=>{try{const m=JSON.parse(e.data);if(m.type==='offer'){await pc.setRemoteDescription({type:'offer',sdp:m.sdp});for(const c of pending)await pc.addIceCandidate(c);pending=[];const a=await pc.createAnswer();await pc.setLocalDescription(a);ws.send(JSON.stringify({type:'answer',sdp:a.sdp}));}else if(m.type==='candidate'){const c={candidate:m.candidate,sdpMid:m.sdpMid,sdpMLineIndex:m.sdpMLineIndex};if(pc.remoteDescription)await pc.addIceCandidate(c);else pending.push(c);}}catch(err){status.textContent='WebRTC error: '+err.message;}};
 ws.onclose=()=>{status.textContent='Signaling disconnected';};
 ws.onerror=()=>{status.textContent='Cannot reach WebRTC signaling';};
 try{if(video.requestFullscreen)video.requestFullscreen().catch(()=>{});}catch(e){}
}
document.getElementById('connect').addEventListener('click',connect);
document.getElementById('ignore').addEventListener('click',()=>{consent.innerHTML='<div class="panel"><h2>Connection ignored</h2><p class="desc">You can close this page. Start casting again from the phone to show a new request.</p></div>';});
</script></body></html>
"""

    fun stop() {
        running = false
        runCatching { server?.close() }
        clients.forEach { runCatching { it.sock.close() } }; clients.clear()
    }

    private fun page(codec: String, token: String) = """
<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>html,body{margin:0;height:100%;background:#000;overflow:hidden}video{width:100%;height:100%;object-fit:contain;background:#000}
#snd{position:fixed;left:50%;bottom:6%;transform:translateX(-50%);padding:14px 28px;border-radius:30px;background:rgba(40,40,40,.85);color:#fff;font:600 24px sans-serif;display:none}#status{position:fixed;top:12px;left:12px;color:#fff;background:#1119;padding:7px 10px;border-radius:8px;font:13px sans-serif}</style>
</head><body><video id="v" autoplay playsinline></video><div id="snd">Press OK to turn on sound</div><div id="status">ScreenCast · Live</div><script>
var v=document.getElementById('v'),snd=document.getElementById('snd'),status=document.getElementById('status'),ms=new MediaSource(),q=[],sb=null,rd=null,started=false,reading=false;
v.src=URL.createObjectURL(ms);
function unmute(){v.muted=false;v.play().catch(function(){});snd.style.display='none';}
document.addEventListener('click',unmute);document.addEventListener('keydown',unmute);document.addEventListener('touchstart',unmute);
function firstPlay(){if(started)return;started=true;v.muted=false;
 v.play().catch(function(){v.muted=true;v.play().catch(function(){});snd.style.display='block';});}
function readNext(){
 if(!rd||reading||q.length||!sb||sb.updating)return;
 reading=true;
 rd.read().then(function(x){reading=false;if(x.done){location.reload();return;}
  q.push(x.value);pump();firstPlay();
 }).catch(function(){setTimeout(function(){location.reload();},2000);});
}
function pump(){
 if(!sb||sb.updating)return;
 if(q.length){try{sb.appendBuffer(q[0]);q.shift();}catch(e){if(e.name==='QuotaExceededError'){try{var a=sb.buffered.start(0);if(v.currentTime-a>1)sb.remove(a,v.currentTime-0.5);}catch(x){} }else{status.textContent='Buffering…';}}}
 else readNext();
}
function trim(){try{if(!sb||!sb.buffered.length)return;
 var n=sb.buffered.length,s=sb.buffered.start(n-1),e=sb.buffered.end(n-1),lag=e-v.currentTime;
 // Keep a small live buffer; jump only after a real backlog, not on every half-second tick.
 if(v.currentTime<s-0.1||lag>0.9){v.currentTime=Math.max(s,e-0.25);}
 var s0=sb.buffered.start(0);
 if(!sb.updating&&v.currentTime-s0>8){sb.remove(s0,Math.max(s0,v.currentTime-4));}
 }catch(x){}}
ms.addEventListener('sourceopen',function(){
 sb=ms.addSourceBuffer('video/mp4; codecs="$codec"');
 sb.addEventListener('updateend',function(){trim();pump();});
 fetch('/live.mp4?k=$token').then(function(r){if(!r.ok)throw new Error('Stream unavailable');rd=r.body.getReader();readNext();})
 .catch(function(){setTimeout(function(){location.reload();},2000);});
});
setInterval(trim,1000);
</script></body></html>"""
}
