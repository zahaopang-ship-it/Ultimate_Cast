package com.example.screencast

import android.content.Context
import android.content.Intent
import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Process
import java.nio.ByteBuffer
import kotlin.concurrent.thread
import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONObject
import org.webrtc.*
import java.net.InetSocketAddress
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean

/** WebRTC screen-video + device-playback-audio transport. MSE remains a separate fallback. */
class WebRtcTransport(
    private val context: Context,
    private val resultCode: Int,
    private val capturePermission: Intent,
    private val token: String,
    private val width: Int,
    private val height: Int,
    private val fps: Int,
    private val audioEnabled: Boolean,
    private val onState: (String) -> Unit = {}
) {
    private val stopped = AtomicBoolean(false)
    private var egl: EglBase? = null
    private var factory: PeerConnectionFactory? = null
    private var capturer: WebRtcProjectionCapturer? = null
    private var mediaProjection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    private var audioThread: Thread? = null
    @Volatile private var audioRunning = false
    private var audioChannel: DataChannel? = null
    private var textureHelper: SurfaceTextureHelper? = null
    private var source: VideoSource? = null
    private var peer: PeerConnection? = null
    private var signaling: SignalServer? = null
    @Volatile private var remoteDescriptionSet = false
    private val pendingRemoteCandidates = mutableListOf<IceCandidate>()

    fun start() {
        try {
            initializeWebRtc()
            signaling = SignalServer(8081, token, ::onSignal).also { it.start() }
            onState("Waiting for TV browser to connect")
        } catch (t: Throwable) {
            onState("WebRTC start failed: ${t.message ?: "unknown error"}")
            stop()
        }
    }

    @Synchronized private fun initializeWebRtc() {
        if (factory != null) return
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context.applicationContext).createInitializationOptions()
        )
        egl = EglBase.create()
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(egl!!.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl!!.eglBaseContext))
            .createPeerConnectionFactory()
        source = factory!!.createVideoSource(false)
        textureHelper = SurfaceTextureHelper.create("ScreenCast-WebRTC", egl!!.eglBaseContext)
        mediaProjection = context.getSystemService(MediaProjectionManager::class.java)
            .getMediaProjection(resultCode, capturePermission)
        capturer = WebRtcProjectionCapturer(mediaProjection!!) { stop() }
        capturer!!.initialize(textureHelper!!, context, source!!.capturerObserver)
        capturer!!.startCapture(width, height, fps)
        startPlaybackAudio()
    }

    private fun onSignal(conn: WebSocket, raw: String) {
        try {
            val msg = JSONObject(raw)
            when (msg.optString("type")) {
                "ready" -> createPeerAndOffer(conn)
                "closed" -> {
                    remoteDescriptionSet = false
                    synchronized(pendingRemoteCandidates) { pendingRemoteCandidates.clear() }
                    runCatching { audioChannel?.close(); audioChannel?.dispose() }
                    audioChannel = null
                    runCatching { peer?.close(); peer?.dispose() }
                    peer = null
                }
                "answer" -> {
                    val sdp = SessionDescription(SessionDescription.Type.ANSWER, msg.getString("sdp"))
                    peer?.setRemoteDescription(object : SimpleSdpObserver() {
                        override fun onSetSuccess() {
                            remoteDescriptionSet = true
                            synchronized(pendingRemoteCandidates) {
                                pendingRemoteCandidates.forEach { peer?.addIceCandidate(it) }
                                pendingRemoteCandidates.clear()
                            }
                        }
                        override fun onSetFailure(error: String) { onState("WebRTC answer rejected: $error") }
                    }, sdp)
                }
                "candidate" -> {
                    val candidate = IceCandidate(msg.optString("sdpMid"), msg.optInt("sdpMLineIndex"), msg.getString("candidate"))
                    if (remoteDescriptionSet) peer?.addIceCandidate(candidate)
                    else synchronized(pendingRemoteCandidates) { pendingRemoteCandidates.add(candidate) }
                }
            }
        } catch (t: Throwable) { onState("WebRTC signaling error: ${t.message}") }
    }

    private fun createPeerAndOffer(conn: WebSocket) {
        if (peer != null) return
        val ice = listOf(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer())
        val config = PeerConnection.RTCConfiguration(ice).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
        }
        peer = factory!!.createPeerConnection(config, object : PeerConnection.Observer {
            override fun onSignalingChange(state: PeerConnection.SignalingState) {}
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) {
                onState("WebRTC: ${state.name.lowercase()}")
            }
            override fun onIceConnectionReceivingChange(receiving: Boolean) {}
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) {}
            override fun onIceCandidate(candidate: IceCandidate) {
                signaling?.send(JSONObject().put("type", "candidate").put("sdpMid", candidate.sdpMid)
                    .put("sdpMLineIndex", candidate.sdpMLineIndex).put("candidate", candidate.sdp).toString())
            }
            override fun onIceCandidatesRemoved(candidates: Array<IceCandidate>) {}
            override fun onAddStream(stream: MediaStream) {}
            override fun onRemoveStream(stream: MediaStream) {}
            override fun onDataChannel(channel: DataChannel) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(receiver: RtpReceiver, streams: Array<MediaStream>) {}
            override fun onTrack(transceiver: RtpTransceiver) {}
            override fun onConnectionChange(state: PeerConnection.PeerConnectionState) {}
            override fun onStandardizedIceConnectionChange(state: PeerConnection.IceConnectionState) {}
        }) ?: throw IllegalStateException("Could not create WebRTC peer connection")
        val track = factory!!.createVideoTrack("screencast-video", source!!)
        peer!!.addTrack(track, listOf("screencast"))
        val dcInit = DataChannel.Init().apply { ordered = true }
        audioChannel = peer!!.createDataChannel("screencast-audio", dcInit)
        peer!!.createOffer(object : SimpleSdpObserver() {
            override fun onCreateSuccess(desc: SessionDescription) {
                peer?.setLocalDescription(object : SimpleSdpObserver() {
                    override fun onSetSuccess() {
                        signaling?.send(JSONObject().put("type", "offer").put("sdp", desc.description).toString())
                    }
                    override fun onSetFailure(error: String) { onState("WebRTC local SDP failed: $error") }
                }, desc)
            }
            override fun onCreateFailure(error: String) { onState("WebRTC offer failed: $error") }
        }, MediaConstraints())
    }

    fun stop() {
        if (!stopped.compareAndSet(false, true)) return
        audioRunning = false
        runCatching { audioRecord?.stop() }
        runCatching { audioRecord?.release() }
        audioRecord = null
        runCatching { audioThread?.join(300) }
        audioThread = null
        runCatching { audioChannel?.close(); audioChannel?.dispose() }
        audioChannel = null
        runCatching { capturer?.stopCapture() }
        runCatching { capturer?.dispose() }
        runCatching { peer?.close(); peer?.dispose() }
        runCatching { source?.dispose() }
        runCatching { textureHelper?.dispose() }
        runCatching { factory?.dispose() }
        runCatching { egl?.release() }
        runCatching { mediaProjection?.stop() }
        mediaProjection = null
        runCatching { signaling?.stop() }
        peer = null; capturer = null; source = null; textureHelper = null; factory = null; egl = null
    }

    /** Captures device playback (not microphone) and sends low-latency 48 kHz stereo PCM over a WebRTC data channel. */
    private fun startPlaybackAudio() {
        if (!audioEnabled) { onState("WebRTC video ready · phone audio disabled in settings"); return }
        if (Build.VERSION.SDK_INT < 29 || context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            onState("WebRTC video ready · phone audio permission unavailable")
            return
        }
        val projection = mediaProjection ?: return
        try {
            val config = AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val format = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(48_000).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
            val minBuffer = AudioRecord.getMinBufferSize(48_000, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            val record = AudioRecord.Builder().setAudioFormat(format)
                .setBufferSizeInBytes(maxOf(minBuffer * 4, 32_768))
                .setAudioPlaybackCaptureConfig(config).build()
            if (record.state != AudioRecord.STATE_INITIALIZED) {
                record.release(); onState("WebRTC video ready · phone audio capture unavailable"); return
            }
            audioRecord = record
            record.startRecording()
            audioRunning = true
            audioThread = thread(name = "WebRTC-playback-audio", isDaemon = true) {
                Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
                val packetBytes = 48_000 / 50 * 2 * 2 // 20 ms, stereo, signed 16-bit
                val packet = ByteArray(packetBytes)
                try {
                    while (audioRunning) {
                        var filled = 0
                        while (filled < packet.size && audioRunning) {
                            val n = record.read(packet, filled, packet.size - filled)
                            if (n > 0) filled += n else if (n < 0) { audioRunning = false; break }
                        }
                        if (filled != packet.size || !audioRunning) continue
                        val channel = audioChannel
                        if (channel != null && channel.state() == DataChannel.State.OPEN && channel.bufferedAmount() < 256_000) {
                            channel.send(DataChannel.Buffer(ByteBuffer.wrap(packet.copyOf()), true))
                        }
                    }
                } catch (_: Throwable) { }
            }
            onState("WebRTC video + phone audio ready")
        } catch (t: Throwable) {
            onState("WebRTC video ready · phone audio unavailable: ${t.message ?: "capture error"}")
        }
    }

    private class SignalServer(port: Int, private val token: String, private val receiver: (WebSocket, String) -> Unit) :
        WebSocketServer(InetSocketAddress(port)) {
        @Volatile private var active: WebSocket? = null
        override fun onOpen(conn: WebSocket, handshake: ClientHandshake) {
            val query = handshake.resourceDescriptor.substringAfter('?', "")
            val supplied = query.split('&').firstOrNull { it.startsWith("k=") }?.substringAfter('=') ?: ""
            if (!MessageDigest.isEqual(supplied.toByteArray(), token.toByteArray())) {
                conn.close(1008, "Invalid session token"); return
            }
            active?.takeIf { it.isOpen }?.close(1000, "Replaced by new receiver")
            active = conn
            receiver(conn, "{\"type\":\"ready\"}")
        }
        override fun onMessage(conn: WebSocket, message: String) { if (conn == active) receiver(conn, message) }
        override fun onClose(conn: WebSocket, code: Int, reason: String, remote: Boolean) {
            if (conn == active) { active = null; receiver(conn, "{\"type\":\"closed\"}") }
        }
        override fun onError(conn: WebSocket?, ex: Exception) {}
        override fun onStart() {}
        fun send(message: String) { active?.takeIf { it.isOpen }?.send(message) }
    }

    private open class SimpleSdpObserver : SdpObserver {
        override fun onCreateSuccess(desc: SessionDescription) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(error: String) {}
        override fun onSetFailure(error: String) {}
    }
}
