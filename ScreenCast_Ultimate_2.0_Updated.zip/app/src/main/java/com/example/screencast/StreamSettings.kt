package com.example.screencast

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow

/** User-selectable encoder settings. Values are snapshotted when a casting session starts. */
data class StreamConfig(
    val resolution: String = "1080p",
    val frameRate: Int = 30,
    val bitrateMbps: Int = 6,
    val audioEnabled: Boolean = true
) {
    val width: Int get() = if (resolution == "720p") 1280 else 1920
    val height: Int get() = if (resolution == "720p") 720 else 1080
    val bitrate: Int get() = bitrateMbps * 1_000_000
}

object StreamSettings {
    val config = MutableStateFlow(StreamConfig())

    fun load(context: Context) {
        val p = context.getSharedPreferences("stream_settings", Context.MODE_PRIVATE)
        config.value = StreamConfig(
            resolution = p.getString("resolution", "1080p") ?: "1080p",
            frameRate = p.getInt("fps", 30).coerceIn(24, 60),
            bitrateMbps = p.getInt("bitrate", 6).coerceIn(2, 15),
            audioEnabled = p.getBoolean("audio", true)
        )
    }

    fun update(context: Context, value: StreamConfig) {
        config.value = value
        context.getSharedPreferences("stream_settings", Context.MODE_PRIVATE).edit()
            .putString("resolution", value.resolution)
            .putInt("fps", value.frameRate)
            .putInt("bitrate", value.bitrateMbps)
            .putBoolean("audio", value.audioEnabled)
            .apply()
    }
}
