package com.example.screencast

import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread

/**
 * Tiny HTTP server:  GET /          -> full-screen player page (MediaSource Extensions, live-edge catch-up)
 *                    GET /live.mp4  -> endless fragmented MP4 (init segment, then frames from a keyframe)
 * Each viewer has its own queue + writer thread, so a slow TV can never stall the encoder.
 */
class LiveServer(private val port: Int, private val token: String, private val requestKeyFrame: () -> Unit, private val onCongestion: () -> Unit = {}) {
    @Volatile var initSegment: ByteArray? = null
    @Volatile var codec: String = "avc1.640028"

    private class Client(val sock: Socket) {
        val q = LinkedBlockingQueue<ByteArray>(90)
        @Volatile var needKey = true
    }

    private val clients = CopyOnWriteArrayList<Client>()
    private val dropped = AtomicLong(0)
    val viewerCount: Int get() = clients.size
    val droppedFragments: Long get() = dropped.get()
    private var server: ServerSocket? = null
    @Volatile private var running = false

    fun start() {
        running = true
        thread(name = "live-accept", isDaemon = true) {
            try {
                server = ServerSocket(port)
                while (running) { val s = server!!.accept(); thread(isDaemon = true) { handle(s) } }
            } catch (_: Exception) { }
        }
    }

    private fun handle(s: Socket) {
        var c: Client? = null
        try {
            s.tcpNoDelay = true
            s.soTimeout = 10_000 // never let a half-open HTTP request occupy a worker forever
            val br = s.getInputStream().bufferedReader()
            val path = br.readLine()?.split(" ")?.getOrNull(1) ?: return
            while (br.readLine()?.isNotEmpty() == true) { }
            val out = s.getOutputStream()

            // Secret code check: every request (page AND stream) must carry ?k=<token>.
            val given = Regex("[?&]k=([A-Za-z0-9]+)").find(path)?.groupValues?.get(1)?.uppercase() ?: ""
            if (!MessageDigest.isEqual(given.toByteArray(), token.toByteArray())) {
                Thread.sleep(300) // slows down guessing
                val msg = "Forbidden: wrong or missing code".toByteArray()
                out.write(("HTTP/1.1 403 Forbidden\r\nContent-Type: text/plain\r\nContent-Length: ${msg.size}\r\nConnection: close\r\n\r\n").toByteArray())
                out.write(msg); out.flush()
                return
            }

            if (path.startsWith("/live.mp4")) {
                if (clients.size >= 3) {
                    val msg = "Too many viewers".toByteArray()
                    out.write(("HTTP/1.1 503 Service Unavailable\r\nContent-Length: ${msg.size}\r\nConnection: close\r\n\r\n").toByteArray())
                    out.write(msg); out.flush(); return
                }
                s.soTimeout = 0
                var waited = 0
                while (initSegment == null && waited++ < 50) Thread.sleep(100)
                val init = initSegment ?: return
                out.write(("HTTP/1.1 200 OK\r\nContent-Type: video/mp4\r\nCache-Control: no-cache\r\n" +
                        "Access-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n").toByteArray())
                out.write(init); out.flush()
                c = Client(s).also { clients.add(it) }
                requestKeyFrame()
                while (running) {
                    val b = c.q.poll(2, TimeUnit.SECONDS) ?: continue
                    out.write(b); out.flush()
                }
            } else {
                val body = page(codec, token).toByteArray()
                out.write(("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nCache-Control: no-store\r\nReferrer-Policy: no-referrer\r\n" +
                        "Content-Length: ${body.size}\r\nConnection: close\r\n\r\n").toByteArray())
                out.write(body); out.flush()
            }
        } catch (_: Exception) {
        } finally {
            c?.let { clients.remove(it) }
            runCatching { s.close() }
        }
    }

    /** Called from the encoder callback thread for every encoded frame. */
    fun push(fragment: ByteArray, key: Boolean) {
        for (c in clients) {
            if (c.needKey) { if (!key) continue; c.needKey = false }
            if (!c.q.offer(fragment)) { dropped.incrementAndGet(); c.q.clear(); c.needKey = true; requestKeyFrame(); onCongestion() } // too slow: resync
        }
    }

    /** Audio frames: only sent to viewers that already started (i.e. after their first video keyframe). */
    fun pushAudio(fragment: ByteArray) {
        for (c in clients) {
            if (c.needKey) continue
            if (!c.q.offer(fragment)) { dropped.incrementAndGet(); c.q.clear(); c.needKey = true; requestKeyFrame(); onCongestion() }
        }
    }

    fun stop() {
        running = false
        runCatching { server?.close() }
        clients.forEach { runCatching { it.sock.close() } }; clients.clear()
    }

    private fun page(codec: String, token: String) = """
<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>html,body{margin:0;height:100%;background:#000;overflow:hidden}video{width:100%;height:100%;object-fit:contain;background:#000}
#snd{position:fixed;left:50%;bottom:6%;transform:translateX(-50%);padding:14px 28px;border-radius:30px;background:rgba(40,40,40,.85);color:#fff;font:600 24px sans-serif;display:none}#status{position:fixed;top:12px;left:12px;color:#fff;background:#1119;padding:7px 10px;border-radius:8px;font:13px sans-serif}</style>
</head><body><video id="v" autoplay playsinline></video><div id="snd">Press OK to turn on sound</div><div id="status">ScreenCast · Live</div><script>
var v=document.getElementById('v'),snd=document.getElementById('snd'),status=document.getElementById('status'),ms=new MediaSource(),q=[],sb=null,rd=null,started=false,reading=false;
v.src=URL.createObjectURL(ms);
function unmute(){v.muted=false;v.play().catch(function(){});snd.style.display='none';}
document.addEventListener('click',unmute);document.addEventListener('keydown',unmute);document.addEventListener('touchstart',unmute);
function firstPlay(){if(started)return;started=true;v.muted=false;
 v.play().catch(function(){v.muted=true;v.play().catch(function(){});snd.style.display='block';});}
function readNext(){
 if(!rd||reading||q.length||!sb||sb.updating)return;
 reading=true;
 rd.read().then(function(x){reading=false;if(x.done){location.reload();return;}
  q.push(x.value);pump();firstPlay();
 }).catch(function(){setTimeout(function(){location.reload();},2000);});
}
function pump(){
 if(!sb||sb.updating)return;
 if(q.length){try{sb.appendBuffer(q[0]);q.shift();}catch(e){if(e.name==='QuotaExceededError'){try{var a=sb.buffered.start(0);if(v.currentTime-a>1)sb.remove(a,v.currentTime-0.5);}catch(x){} }else{status.textContent='Buffering…';}}}
 else readNext();
}
function trim(){try{if(!sb||!sb.buffered.length)return;
 var n=sb.buffered.length,s=sb.buffered.start(n-1),e=sb.buffered.end(n-1),lag=e-v.currentTime;
 // Keep a small live buffer; jump only after a real backlog, not on every half-second tick.
 if(v.currentTime<s-0.1||lag>1.25){v.currentTime=Math.max(s,e-0.3);}
 var s0=sb.buffered.start(0);
 if(!sb.updating&&v.currentTime-s0>8){sb.remove(s0,Math.max(s0,v.currentTime-4));}
 }catch(x){}}
ms.addEventListener('sourceopen',function(){
 sb=ms.addSourceBuffer('video/mp4; codecs="$codec"');
 sb.addEventListener('updateend',function(){trim();pump();});
 fetch('/live.mp4?k=$token').then(function(r){if(!r.ok)throw new Error('Stream unavailable');rd=r.body.getReader();readNext();})
 .catch(function(){setTimeout(function(){location.reload();},2000);});
});
setInterval(trim,1000);
</script></body></html>"""
}
