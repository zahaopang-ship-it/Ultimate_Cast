package com.example.screencast

import android.graphics.Rect
import android.util.Size
import kotlin.math.min
import kotlin.math.roundToInt

/** Everything the pipeline needs for one orientation/mode combination. */
data class FrameSpec(
    val captureW: Int, val captureH: Int, val captureDpi: Int, // VirtualDisplay config
    val outW: Int, val outH: Int,                              // ALWAYS the TV size (constant stream resolution)
    val srcCrop: Rect,                                         // region of the capture to copy
    val dst: Rect                                              // where it lands inside the TV frame
)

/**
 * The stream resolution NEVER changes (always [tvTarget]). Many TV players lock onto the first
 * frame size and stretch later frames of a different size, so rotation only changes what is drawn
 * INSIDE the fixed 16:9 frame:
 *  - Landscape + autoFullscreen : center-crop the capture to 16:9 and fill the whole frame.
 *  - Otherwise (portrait, or toggle off): fit the capture, centered, aspect preserved (black bars).
 */
class AspectScaleManager(
    private val nativeShort: Int,
    private val nativeLong: Int,
    private val nativeDpi: Int,
    private val tvTarget: Size = Size(1920, 1080),
    private val maxCaptureLong: Int = 2560
) {
    fun compute(landscape: Boolean, autoFullscreen: Boolean): FrameSpec {
        val scale = min(1f, maxCaptureLong.toFloat() / nativeLong)
        val s = even(nativeShort * scale)
        val l = even(nativeLong * scale)
        val capW = if (landscape) l else s
        val capH = if (landscape) s else l
        val dpi = (nativeDpi * scale).roundToInt().coerceAtLeast(72)
        val outW = tvTarget.width
        val outH = tvTarget.height
        val full = Rect(0, 0, capW, capH)

        if (landscape && autoFullscreen) {
            val tvAspect = outW.toFloat() / outH
            val capAspect = capW.toFloat() / capH
            val crop = if (capAspect > tvAspect) {
                val w = even(capH * tvAspect); val x = (capW - w) / 2
                Rect(x, 0, x + w, capH)
            } else {
                val h = even(capW / tvAspect); val y = (capH - h) / 2
                Rect(0, y, capW, y + h)
            }
            return FrameSpec(capW, capH, dpi, outW, outH, crop, Rect(0, 0, outW, outH))
        }

        // Fit inside the fixed frame (portrait mirrored as-is, centered).
        val f = min(outW.toFloat() / capW, outH.toFloat() / capH)
        val w = even(capW * f); val h = even(capH * f)
        val x = (outW - w) / 2; val y = (outH - h) / 2
        return FrameSpec(capW, capH, dpi, outW, outH, full, Rect(x, y, x + w, y + h))
    }

    private fun even(v: Float) = (v.roundToInt() / 2) * 2
}
