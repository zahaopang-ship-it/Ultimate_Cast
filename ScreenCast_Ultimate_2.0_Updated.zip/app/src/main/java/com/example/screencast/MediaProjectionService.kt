package com.example.screencast

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.util.Size
import android.view.Display
import android.view.OrientationEventListener
import android.view.Surface
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import java.net.NetworkInterface
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** Shared, observable state for the UI. */
object StreamState {
    val autoFullscreen = MutableStateFlow(true)
    val running = MutableStateFlow(false)
    val streamUrl = MutableStateFlow<String?>(null)
    val fps = MutableStateFlow(0)
    val bitrateKbps = MutableStateFlow(0)
    val viewers = MutableStateFlow(0)
    val droppedFragments = MutableStateFlow(0L)
}

/**
 * Pipeline:  screen -> VirtualDisplay -> SurfaceTexture -> GL (crop/fit) -> H.264 encoder (fixed 1920x1080)
 *            -> fragmented MP4 -> HTTP -> TV browser (MSE).
 * The encoder resolution NEVER changes, so TVs/browsers never see a resolution switch on rotation.
 * Android 14+: one createVirtualDisplay per projection token, so rotation uses resize().
 */
class MediaProjectionService : Service() {

    private val worker = HandlerThread("capture").apply { start() }
    private val handler by lazy { Handler(worker.looper) }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var scaler: AspectScaleManager? = null
    private var spec: FrameSpec? = null
    private var controlUrl: String? = null
    private var orientationListener: OrientationEventListener? = null
    private var autoJob: Job? = null

    private var encoder: MediaCodec? = null
    private var renderer: GlRenderer? = null
    private var muxer = Fmp4Muxer(OUT_W, OUT_H, false)
    private var sessionConfig = StreamConfig()
    private var framesWindow = 0
    private var bytesWindow = 0L
    private var statsWindowStart = SystemClock.elapsedRealtime()
    private var activeBitrate = 0
    private var lastCongestionAt = 0L

    // ---- audio (AudioPlaybackCapture -> AAC) ----
    private var audioRecord: AudioRecord? = null
    private var audioEnc: MediaCodec? = null
    private var audioThread: Thread? = null
    @Volatile private var audioRunning = false
    // New random code for every casting session (the service is recreated on each start).
    private val token = newToken()
    private val server = LiveServer(PORT, token, { requestKeyFrame() }, { reduceBitrateOnCongestion() })

    private fun newToken(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" // no look-alikes (0/O, 1/I)
        val rnd = java.security.SecureRandom()
        return (1..16).map { chars[rnd.nextInt(chars.length)] }.joinToString("")
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> if (projection == null) startCasting(intent)
            ACTION_STOP -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startCasting(intent: Intent) {
        startForegroundCompat() // must come before MediaProjection on API 34+

        val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
        controlUrl = intent.getStringExtra(EXTRA_CONTROL_URL)
        sessionConfig = StreamSettings.config.value
        if (data == null || code != Activity.RESULT_OK) { stopSelf(); return }

        projection = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data).apply {
            registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, handler)
        }

        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        scaler = AspectScaleManager(
            nativeShort = minOf(dm.widthPixels, dm.heightPixels),
            nativeLong = maxOf(dm.widthPixels, dm.heightPixels),
            nativeDpi = dm.densityDpi,
            tvTarget = Size(sessionConfig.width, sessionConfig.height)
        )

        handler.post { startPipeline() }

        orientationListener = object : OrientationEventListener(this, SensorManager.SENSOR_DELAY_NORMAL) {
            override fun onOrientationChanged(o: Int) {
                if (o == ORIENTATION_UNKNOWN) return
                handler.removeCallbacks(refreshRunnable)
                handler.postDelayed(refreshRunnable, 350) // debounce; Display.rotation is the truth
            }
        }.also { if (it.canDetectOrientation()) it.enable() }

        autoJob = scope.launch { StreamState.autoFullscreen.collect { handler.post { refresh() } } }

        val ip = localIp()
        StreamState.streamUrl.value = "http://$ip:$PORT/?k=$token"
        StreamState.running.value = true
        controlUrl?.let { c -> scope.launch { runCatching { Dlna.play(c, "http://$ip:$PORT/live.mp4?k=$token") } } }
    }

    /** Runs on the capture thread: encoder first (gives the input surface), then GL, then the VirtualDisplay. */
    private fun startPipeline() {
        val audioPossible = sessionConfig.audioEnabled && Build.VERSION.SDK_INT >= 29 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        muxer = Fmp4Muxer(sessionConfig.width, sessionConfig.height, audioPossible, sessionConfig.frameRate)
        server.start()
        val encSurface = startEncoder()
        renderer = GlRenderer(encSurface, sessionConfig.width, sessionConfig.height).also { r ->
            r.init(handler) { runCatching { r.draw() } }
        }
        refresh()

        if (audioPossible && !startAudio()) { muxer.disableAudio(); publishInit() }
        // Safety net: if audio never produces its config (e.g. capture blocked), fall back to video-only.
        handler.postDelayed({ if (!muxer.ready) { muxer.disableAudio(); publishInit() } }, 3000)
    }

    private fun publishInit() {
        if (muxer.ready) { server.codec = muxer.codec!!; server.initSegment = muxer.initSegment }
    }

    /** Captures what the phone is playing (media/games/unknown) and encodes it to AAC-LC 48 kHz stereo. */
    private fun startAudio(): Boolean {
        val proj = projection ?: return false
        return try {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(proj)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val pcm = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
            val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = AudioRecord.Builder().setAudioFormat(pcm)
                .setBufferSizeInBytes(maxOf(minBuf * 2, 16384))
                .setAudioPlaybackCaptureConfig(cfg).build()
            if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return false }
            val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, 2).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            enc.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()
            audioRecord = rec; audioEnc = enc
            audioRunning = true
            rec.startRecording()
            audioThread = thread(name = "audio", isDaemon = true) { audioLoop(rec, enc) }
            true
        } catch (e: Exception) { false }
    }

    private fun audioLoop(rec: AudioRecord, enc: MediaCodec) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val pcm = ByteArray(4096) // 1024 stereo frames = exactly one AAC frame
        val info = MediaCodec.BufferInfo()
        var anchorUs = -1L; var frames = 0L
        try {
            while (audioRunning) {
                val n = rec.read(pcm, 0, pcm.size)
                if (n <= 0) { Thread.sleep(5); continue }
                val nFrames = n / 4
                if (anchorUs < 0) anchorUs = System.nanoTime() / 1000 - nFrames * 1_000_000L / SAMPLE_RATE
                val idx = enc.dequeueInputBuffer(10_000)
                if (idx >= 0) {
                    val ib = enc.getInputBuffer(idx)!!
                    ib.clear(); ib.put(pcm, 0, n)
                    enc.queueInputBuffer(idx, 0, n, anchorUs + frames * 1_000_000L / SAMPLE_RATE, 0)
                }
                // If the encoder is temporarily full, this PCM block is dropped but its elapsed
                // time must still be reflected in the next input PTS (otherwise audio runs slow).
                frames += nFrames
                while (true) {
                    val o = enc.dequeueOutputBuffer(info, 0)
                    if (o < 0) break
                    val ob = enc.getOutputBuffer(o)
                    val bytes = if (ob != null && info.size > 0) {
                        ob.position(info.offset); ob.limit(info.offset + info.size)
                        ByteArray(info.size).also { ob.get(it) }
                    } else null
                    enc.releaseOutputBuffer(o, false)
                    if (bytes == null) continue
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) { muxer.setAudioConfig(bytes); publishInit() }
                    else muxer.audioFragment(bytes, info.presentationTimeUs)?.let { server.pushAudio(it) }
                }
            }
        } catch (_: Exception) { }
    }

    private fun startEncoder(): Surface {
        activeBitrate = sessionConfig.bitrate
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, sessionConfig.width, sessionConfig.height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, activeBitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, sessionConfig.frameRate)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            setLong("repeat-previous-frame-after", 100_000L) // keep emitting frames when the screen is static
            if (Build.VERSION.SDK_INT >= 23) setInteger(MediaFormat.KEY_PRIORITY, 0) // real-time
            if (Build.VERSION.SDK_INT >= 29) setInteger(MediaFormat.KEY_MAX_B_FRAMES, 0)
            if (Build.VERSION.SDK_INT >= 30) setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        enc.setCallback(object : MediaCodec.Callback() {
            override fun onInputBufferAvailable(c: MediaCodec, i: Int) {}
            override fun onOutputFormatChanged(c: MediaCodec, f: MediaFormat) {}
            override fun onError(c: MediaCodec, e: MediaCodec.CodecException) { stopSelf() }
            override fun onOutputBufferAvailable(c: MediaCodec, index: Int, info: MediaCodec.BufferInfo) {
                val buf = c.getOutputBuffer(index)
                val bytes = if (buf != null && info.size > 0) {
                    buf.position(info.offset); buf.limit(info.offset + info.size)
                    ByteArray(info.size).also { buf.get(it) }
                } else null
                c.releaseOutputBuffer(index, false)
                if (bytes == null) return
                if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                    muxer.setVideoConfig(bytes); publishInit()
                } else {
                    val key = info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0
                    server.push(muxer.videoFragment(bytes, info.presentationTimeUs, key), key)
                    updateStats(bytes.size)
                }
            }
        }, handler)
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = enc.createInputSurface()
        enc.start()
        encoder = enc
        return surface
    }

    /** Step down encoder bitrate on sustained client queue overflow; never changes resolution mid-session. */
    private fun reduceBitrateOnCongestion() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastCongestionAt < 5_000) return
        lastCongestionAt = now
        val next = (activeBitrate * 0.8).toInt().coerceAtLeast(1_000_000)
        if (next >= activeBitrate) return
        activeBitrate = next
        runCatching { encoder?.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_VIDEO_BITRATE, next) }) }
    }

    private fun requestKeyFrame() {
        runCatching {
            encoder?.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) })
        }
    }

    private val refreshRunnable = Runnable { refresh() }

    /** Recompute crop/fit for the current real rotation and resize the VirtualDisplay if needed. */
    private fun refresh() {
        val proj = projection ?: return
        val r = renderer ?: return
        val scaler = scaler ?: return
        val rot = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).rotation
        val landscape = rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270
        val s = scaler.compute(landscape, StreamState.autoFullscreen.value)
        if (s == spec) return
        spec = s

        r.surfaceTexture.setDefaultBufferSize(s.captureW, s.captureH)
        r.setLayout(s.captureW, s.captureH, s.srcCrop, s.dst)
        if (display == null) {
            display = proj.createVirtualDisplay(
                "ScreenCast", s.captureW, s.captureH, s.captureDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.inputSurface, null, handler
            )
        } else {
            display!!.resize(s.captureW, s.captureH, s.captureDpi)
        }
    }

    private fun updateStats(encodedBytes: Int) {
        framesWindow++
        bytesWindow += encodedBytes
        val now = SystemClock.elapsedRealtime()
        if (now - statsWindowStart >= 1000) {
            val seconds = (now - statsWindowStart).coerceAtLeast(1) / 1000.0
            StreamState.fps.value = (framesWindow / seconds).toInt()
            StreamState.bitrateKbps.value = ((bytesWindow * 8.0 / seconds) / 1000.0).toInt()
            StreamState.viewers.value = server.viewerCount
            StreamState.droppedFragments.value = server.droppedFragments
            framesWindow = 0; bytesWindow = 0; statsWindowStart = now
        }
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Screen casting", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0,
            Intent(this, MediaProjectionService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH)
            .setContentTitle("Casting your screen")
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_delete, "Stop", stop).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun localIp(): String =
        NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
            .firstOrNull { !it.isLoopbackAddress && it.isSiteLocalAddress && it.address.size == 4 }
            ?.hostAddress ?: "0.0.0.0"

    override fun onDestroy() {
        controlUrl?.let { runBlocking(Dispatchers.IO) { withTimeoutOrNull(1500) { Dlna.stop(it) } } }
        autoJob?.cancel(); scope.cancel()
        orientationListener?.disable()
        audioRunning = false
        runCatching { audioThread?.join(500) }
        runCatching { audioRecord?.stop(); audioRecord?.release() }
        runCatching { audioEnc?.stop(); audioEnc?.release() }
        runCatching { display?.release() }
        // EGL objects must be released on the same capture thread that created them.
        runCatching {
            val latch = CountDownLatch(1)
            handler.post { try { renderer?.release() } finally { latch.countDown() } }
            latch.await(700, TimeUnit.MILLISECONDS)
        }
        runCatching { encoder?.stop(); encoder?.release() }
        runCatching { projection?.stop() }
        server.stop(); worker.quitSafely()
        StreamState.running.value = false; StreamState.streamUrl.value = null
        StreamState.fps.value = 0; StreamState.bitrateKbps.value = 0
        StreamState.viewers.value = 0; StreamState.droppedFragments.value = 0
        super.onDestroy()
    }

    companion object {
        const val PORT = 8080
        const val OUT_W = 1920; const val OUT_H = 1080
        private const val SAMPLE_RATE = 48000
        private const val CH = "cast"
        const val ACTION_START = "start"; const val ACTION_STOP = "stop"
        const val EXTRA_RESULT_CODE = "rc"; const val EXTRA_DATA = "data"; const val EXTRA_CONTROL_URL = "ctl"

        fun start(ctx: Context, resultCode: Int, data: Intent, controlUrl: String?) =
            ctx.startForegroundService(Intent(ctx, MediaProjectionService::class.java)
                .setAction(ACTION_START).putExtra(EXTRA_RESULT_CODE, resultCode)
                .putExtra(EXTRA_DATA, data).putExtra(EXTRA_CONTROL_URL, controlUrl))

        fun stop(ctx: Context) = ctx.startService(Intent(ctx, MediaProjectionService::class.java).setAction(ACTION_STOP))
    }
}
