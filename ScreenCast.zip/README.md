# ScreenCast

Android screen mirroring over the local Wi-Fi network. The existing browser-based playback path is retained: Android MediaProjection -> OpenGL -> H.264 MediaCodec -> fragmented MP4 -> HTTP/MSE in the TV browser. Optional app-audio capture uses AudioPlaybackCapture -> AAC.

## Improvements in this build

- Select 720p or 1080p output, 30 or 60 FPS, and 2–15 Mbps video bitrate. Settings are saved and apply to the next session.
- Audio capture is optional. Denying/turning off audio does not prevent video casting. Some source apps intentionally disallow playback capture.
- Live diagnostics show measured video FPS, encoded video bitrate, connected browser viewers, and dropped fragments.
- Session access code expanded from 6 to 16 random characters.
- HTTP request read timeout, maximum of 3 simultaneous viewers, queue overflow accounting, and keyframe resynchronization for slow viewers.
- TV browser playback keeps the existing MSE/fMP4 compatibility route and the DLNA discovery/control flow.

## Important compatibility notes

- 60 FPS and 1080p are device/encoder dependent. If a phone cannot sustain the selected profile, choose 720p/30 FPS and a lower bitrate.
- AudioPlaybackCapture requires Android 10+ and the user's runtime permission. The source app must permit playback capture; protected or restricted apps may remain silent.
- The TV browser must support Media Source Extensions with H.264 (and AAC when audio is enabled). DLNA renderer support varies by vendor/model.
- The app's HTTP stream is intended for a trusted local Wi-Fi network. The session code is a basic access barrier, not TLS encryption. Do not expose port 8080 to the public internet.

## WebRTC status

WebRTC is **not enabled in this source build**. It needs a real peer-connection implementation plus signaling (offer/answer and ICE exchange), browser-side receiver code, lifecycle/reconnect handling, and device/TV interoperability tests. Adding only a WebRTC dependency or a UI switch would not create a working WebRTC transport. The existing HTTP/MSE path is deliberately preserved as the tested fallback until that complete path can be implemented and validated.

## Build

Open the project in Android Studio with JDK 17 and Android SDK 34 installed, then build the `app` debug variant. The archive does not include the Gradle wrapper, so Android Studio/Gradle must supply the build tooling.
