package com.example.screencast

import java.io.ByteArrayOutputStream
import java.io.DataOutputStream

/**
 * Live fragmented-MP4 writer: track 1 = H.264 video, track 2 = AAC audio (optional).
 * Init segment + one moof/mdat per sample. Timestamps (tfdt) come from one shared clock
 * (System.nanoTime) so audio and video stay in sync inside the browser's Media Source Extensions.
 */
class Fmp4Muxer(private val w: Int, private val h: Int, private var audio: Boolean, private val frameRate: Int = 30) {
    @Volatile var initSegment: ByteArray? = null; private set
    @Volatile var codec: String? = null; private set
    val ready: Boolean get() = initSegment != null

    private val VTS = 90000          // video timescale
    private val ATS = 48000          // audio timescale (= sample rate)
    private val baseUs = System.nanoTime() / 1000
    private var sps: ByteArray? = null
    private var pps: ByteArray? = null
    private var asc: ByteArray? = null
    private var seq = 1
    private var lastVideoPts = -1L
    private var audioTfdt = -1L

    /** [annexb] = encoder CODEC_CONFIG buffer (SPS + PPS). */
    @Synchronized fun setVideoConfig(annexb: ByteArray): Boolean {
        for (n in nals(annexb)) when (n[0].toInt() and 0x1F) { 7 -> sps = n; 8 -> pps = n }
        tryBuild()
        return sps != null && pps != null
    }

    /** [a] = AudioSpecificConfig from the AAC encoder's CODEC_CONFIG buffer. */
    @Synchronized fun setAudioConfig(a: ByteArray) { asc = a; tryBuild() }

    /** Called when audio could not start: build a video-only init segment. */
    @Synchronized fun disableAudio() { audio = false; tryBuild() }

    private fun tryBuild() {
        if (initSegment != null) return
        val s = sps ?: return; val p = pps ?: return
        if (audio && asc == null) return
        codec = "avc1.%02X%02X%02X".format(s[1], s[2], s[3]) + if (audio) ",mp4a.40.2" else ""
        initSegment = buildInit(s, p)
    }

    @Synchronized fun videoFragment(annexb: ByteArray, ptsUs: Long, key: Boolean): ByteArray {
        val sample = ByteArrayOutputStream().also { o ->
            DataOutputStream(o).also { d -> for (n in nals(annexb)) { d.writeInt(n.size); d.write(n) } }
        }.toByteArray()
        val dur = if (lastVideoPts < 0) (VTS / frameRate.coerceIn(24, 60)) else ((ptsUs - lastVideoPts) * VTS / 1_000_000).toInt().coerceIn(900, 18000)
        lastVideoPts = ptsUs
        val tfdt = ((ptsUs - baseUs) * VTS / 1_000_000).coerceAtLeast(0)
        return frag(1, tfdt, dur, sample, if (key) 0x02000000 else 0x01010000)
    }

    /** One AAC frame (1024 samples). Audio tfdt starts at the real clock, then advances by exactly 1024 per frame. */
    @Synchronized fun audioFragment(aac: ByteArray, ptsUs: Long): ByteArray? {
        if (!audio || initSegment == null) return null
        if (audioTfdt < 0) audioTfdt = ((ptsUs - baseUs) * ATS / 1_000_000).coerceAtLeast(0)
        val t = audioTfdt; audioTfdt += 1024
        return frag(2, t, 1024, aac, 0x02000000)
    }

    private fun frag(track: Int, tfdt: Long, dur: Int, sample: ByteArray, flags: Int): ByteArray {
        fun moof(off: Int) = box("moof",
            box("mfhd", bytes { writeInt(0); writeInt(seq) }),
            box("traf",
                box("tfhd", bytes { writeInt(0x020000); writeInt(track) }),   // default-base-is-moof
                box("tfdt", bytes { writeInt(0x01000000); writeLong(tfdt) }),
                box("trun", bytes {
                    writeInt(0x000701); writeInt(1); writeInt(off)
                    writeInt(dur); writeInt(sample.size); writeInt(flags)
                })))
        val m = moof(moof(0).size + 8)
        seq++
        return m + box("mdat", sample)
    }

    private fun buildInit(sps: ByteArray, pps: ByteArray): ByteArray {
        val ftyp = box("ftyp", bytes { writeBytes("isom"); writeInt(0x200); writeBytes("isom"); writeBytes("iso5"); writeBytes("avc1"); writeBytes("mp41") })
        val mvhd = box("mvhd", bytes {
            writeInt(0); writeInt(0); writeInt(0); writeInt(VTS); writeInt(0); writeInt(0x10000)
            writeShort(0x0100); writeShort(0); writeInt(0); writeInt(0); matrix(); repeat(6) { writeInt(0) }; writeInt(3)
        })
        val dinf = box("dinf", box("dref", bytes { writeInt(0); writeInt(1) }, box("url ", bytes { writeInt(1) })))
        val empty = bytes { writeInt(0); writeInt(0) }
        val tail = arrayOf(box("stts", empty), box("stsc", empty), box("stsz", bytes { writeInt(0); writeInt(0); writeInt(0) }), box("stco", empty))

        // ---- video track ----
        val avcC = box("avcC", bytes {
            writeByte(1); writeByte(sps[1].toInt()); writeByte(sps[2].toInt()); writeByte(sps[3].toInt())
            writeByte(0xFF); writeByte(0xE1); writeShort(sps.size); write(sps); writeByte(1); writeShort(pps.size); write(pps)
        })
        val avc1 = box("avc1", bytes {
            repeat(6) { writeByte(0) }; writeShort(1); writeShort(0); writeShort(0); repeat(3) { writeInt(0) }
            writeShort(w); writeShort(h); writeInt(0x480000); writeInt(0x480000); writeInt(0); writeShort(1)
            write(ByteArray(32)); writeShort(0x18); writeShort(-1)
        }, avcC)
        val vtrak = trak(1, VTS, "vide", w shl 16, h shl 16, 0,
            box("vmhd", bytes { writeInt(1); writeShort(0); repeat(3) { writeShort(0) } }), dinf,
            box("stbl", box("stsd", bytes { writeInt(0); writeInt(1) }, avc1), *tail))

        var moovParts = arrayOf(mvhd, vtrak)
        var trexes = arrayOf(trex(1))

        // ---- audio track ----
        if (audio) {
            val a = asc!!
            val dsi = byteArrayOf(0x05, a.size.toByte()) + a
            val dcd = byteArrayOf(0x04, (13 + dsi.size).toByte(), 0x40, 0x15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0) + dsi
            val sl = byteArrayOf(0x06, 0x01, 0x02)
            val es = byteArrayOf(0x03, (3 + dcd.size + sl.size).toByte(), 0x00, 0x02, 0x00) + dcd + sl
            val esds = box("esds", bytes { writeInt(0); write(es) })
            val mp4a = box("mp4a", bytes {
                repeat(6) { writeByte(0) }; writeShort(1); writeInt(0); writeInt(0)
                writeShort(2); writeShort(16); writeShort(0); writeShort(0); writeInt(ATS shl 16)
            }, esds)
            val atrak = trak(2, ATS, "soun", 0, 0, 0x0100,
                box("smhd", bytes { writeInt(0); writeShort(0); writeShort(0) }), dinf,
                box("stbl", box("stsd", bytes { writeInt(0); writeInt(1) }, mp4a), *tail))
            moovParts += atrak; trexes += trex(2)
        }
        return ftyp + box("moov", *moovParts, box("mvex", *trexes))
    }

    private fun trak(id: Int, ts: Int, handler: String, width: Int, height: Int, volume: Int, mediaHeader: ByteArray, dinf: ByteArray, stbl: ByteArray): ByteArray {
        val tkhd = box("tkhd", bytes {
            writeInt(3); writeInt(0); writeInt(0); writeInt(id); writeInt(0); writeInt(0); writeInt(0); writeInt(0)
            writeShort(0); writeShort(0); writeShort(volume); writeShort(0); matrix(); writeInt(width); writeInt(height)
        })
        val mdhd = box("mdhd", bytes { writeInt(0); writeInt(0); writeInt(0); writeInt(ts); writeInt(0); writeShort(0x55C4); writeShort(0) })
        val hdlr = box("hdlr", bytes { writeInt(0); writeInt(0); writeBytes(handler); repeat(3) { writeInt(0) }; writeBytes("Handler"); writeByte(0) })
        return box("trak", tkhd, box("mdia", mdhd, hdlr, box("minf", mediaHeader, dinf, stbl)))
    }

    private fun trex(id: Int) = box("trex", bytes { writeInt(0); writeInt(id); writeInt(1); writeInt(0); writeInt(0); writeInt(0) })

    private fun DataOutputStream.matrix() {
        writeInt(0x10000); writeInt(0); writeInt(0); writeInt(0); writeInt(0x10000); writeInt(0); writeInt(0); writeInt(0); writeInt(0x40000000)
    }

    private fun bytes(f: DataOutputStream.() -> Unit): ByteArray {
        val b = ByteArrayOutputStream(); DataOutputStream(b).f(); return b.toByteArray()
    }

    private fun box(type: String, vararg c: ByteArray): ByteArray = bytes {
        writeInt(8 + c.sumOf { it.size }); writeBytes(type); c.forEach { write(it) }
    }

    /** Split an Annex-B buffer into raw NAL units. */
    private fun nals(d: ByteArray): List<ByteArray> {
        val out = ArrayList<ByteArray>(); var start = -1; var i = 0
        fun flush(end: Int) { if (start in 0 until end) out.add(d.copyOfRange(start, end)) }
        while (i + 2 < d.size) {
            if (d[i] == 0.toByte() && d[i + 1] == 0.toByte()) {
                if (d[i + 2] == 1.toByte()) { flush(i); start = i + 3; i += 3; continue }
                if (i + 3 < d.size && d[i + 2] == 0.toByte() && d[i + 3] == 1.toByte()) { flush(i); start = i + 4; i += 4; continue }
            }
            i++
        }
        flush(d.size)
        return out
    }
}
